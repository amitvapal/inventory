import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class InventoryTunesDriver
{

	public static void main(String[] args) throws IOException
	{
		System.out.println("Sports Equipment and Company");
		Scanner inFile = new Scanner(new File("inven.txt"));
		String n, d;
		int stockNum;
		double p;
		
		Inventory list = new Inventory();
		
		/*
		 * print in nice table
		 */
		while(inFile.hasNextLine())
		{
			
			n = inFile.nextLine();
			d = inFile.nextLine();
			
			stockNum = inFile.nextInt();
			
			p = inFile.nextDouble();
			inFile.nextLine();
			
			
			Product newP = new Product(n,d,stockNum,p);
			
			list.addProduct(newP);
			
			
			
			
		}
		inFile.close();
		System.out.println("Current Inventory");
		System.out.println(list);
		System.out.println("");
		System.out.println("");
		
		System.out.println("Menu Choices Choose Number to Display Action");
		System.out.println("0: Display all Products in inventory");
		System.out.println("1: Display the data for single Product ");
		System.out.println("2: Display the value of the current inventory");
		System.out.println("3: Add an Product to the inventory");
		System.out.println("4: Add quantities to the inventory of a product");
		System.out.println("5: Remove quantities from the inventory of a product");
		System.out.println("6: Discontinue a Product when given the id number of the product");
		System.out.println("7: Quit");
		
		String[] choices = {"Display all Products in inventory", "Display the data for single Product", "Display the value of the current inventory",
				"Add an Product to the inventory", "Add quantities to the inventory of a product", "Remove quantities from the inventory of a product",
				"Discontinue a Product when given the id number of the product","Quit"};
		
		
		boolean stop = false;
		int choice;
		while(stop == false)
		{
			System.out.println("");
			System.out.println("");
			choice = inputMethods.menuConsole("Which option do you choose?", choices);
			if(choice>7 || choice<0)
			{
				System.out.println("Please enter valid input");
			}
			if(choice==7)
			{
				System.out.println("Closing program");
				break;
				
			}
			if(choice==0)
			{
				System.out.println("Here are all of the products!");
				System.out.println(list);
			}
			if(choice==1)
			{
				String[] decisons = {"Stock Number", "Product Number"};
				int choice1 = inputMethods.menuConsole("Type of Search ", decisons);
				if(choice1==0)
				{
					System.out.println("What is stock id num: ");
					Scanner input = new Scanner(System.in);
					
				}
			}
			

			
		}

		

		
		
	}

}
